package Base_login_page;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login_Password_GUI implements ActionListener {
    private  JLabel head_label;
    private  JPanel child_panel;
    public   JPanel root_panel;
    private  JTextField User_textField;
    private  JLabel User_label;
    public  JPasswordField passwordField1;
    private  JLabel Password;
    public  JButton loginButton;
    private JLabel error_label;

    @Override
    public void actionPerformed(ActionEvent e)
    {        // if click on button
        //System.out.println(passwordField1.getName());
        //System.out.println(passwordField1.getName());
       // passwordField1.setText("khan");
        error_label.setText("");
        System.out.println("yes i am called on button");
        System.out.println(passwordField1.getPassword());
        char[] get_password = passwordField1.getPassword();
        String set_password = "";
        for(int i = 0; i < get_password.length; i++)
        {
            set_password += get_password[i];
        }
        if(set_password.equals("aamir"))
        {
            System.out.println("valid password");
        }
        else{
            System.out.println("not");
            error_label.setText("Invalid Password");
        }
//        System.out.println(passwordField1.getText() + " password got in e");
 //       System.out.println(pass.passwordField1.getText());
//        String copy_pass = "";
//        for(int i = 0; i < x.length; i++)
//        {
//            copy_pass += x[i];
//        }
//        System.out.println("password is");
//        System.out.println(x);
//        System.out.println("------------");
//        if (copy_pass == "aamir"){
//            System.out.println("yes you are aamir");
//        }
//        if (passwordField1 == "aamir")
//        {
//            System.out.println("Password is correct ");
//        }
//        else{
//        System.out.println("Password is incorrect ");
//        }
    }
    public static void main(String header)
    {
        Login_Password_GUI LOGIN = new Login_Password_GUI();
        //    LOGIN.passwordField1.setText("khan");
    //    head_label.setText(header);
    //    head_label.setText(head_text);

    //    LOGIN.root_panel = new JPanel();
        JFrame frame = new JFrame();
        frame.setSize(800, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //    LOGIN.root_panel = new JPanel();
        frame.setContentPane(LOGIN.root_panel);    // to add the panel to the frame
        frame.setVisible(true);
        LOGIN.loginButton.addActionListener(LOGIN);

        //  LOGIN.button_of_login_password();       // it would enable login button on Login_Password_GUI button

    }

}