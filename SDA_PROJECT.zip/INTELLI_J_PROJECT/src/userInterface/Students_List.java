package userInterface;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class Students_List {
    private JPanel rootPanel;
    private JTable table1;
    public Students_List(){
        createTable();
    }
    public JPanel getRootPanel(){
        return rootPanel;
    }
    private void createTable(){
        Object[][] data = {
                {"Muhammad Aamir Khan", "A", "18P0121"},
        };
        table1.setModel(new DefaultTableModel(
                data,
                new String[]{"Name", "Section", "Roll Number"}
        ));
        TableColumnModel columns = table1.getColumnModel();
        columns.getColumn( 1).setMaxWidth(200); // setting column of section
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for(int i = 0; i < 3; i++)
        {
            columns.getColumn(i).setCellRenderer(centerRenderer);   // setting every column to center
        }
    }

}
