package com.aamir;

import Base_login_page.Base_Login;
import userInterface.Students_List;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
        //        createGUI();
                startPageGUI();

            }
        });
    }

    private static void createGUI(){
        Students_List ui = new Students_List();
        JPanel root = ui.getRootPanel();
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(root);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    }
    private static void startPageGUI()
    {
        Base_Login ui = new Base_Login();
        JPanel get_base_page = ui.create_Base_page();
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(get_base_page);
        frame.pack();
        frame.setSize(800, 500);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        ui.start_base_page();
    }
}
